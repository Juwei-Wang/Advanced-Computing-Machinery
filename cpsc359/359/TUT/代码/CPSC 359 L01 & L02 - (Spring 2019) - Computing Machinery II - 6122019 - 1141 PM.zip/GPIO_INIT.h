#ifndef GPIO_INIT
#define GPIO_INIT

unsigned int *gpioPtr(void);


#endif
